package com.dongsung.SpringExam2;

// 인퍼테이스 안에 있는 모든 메서드는 public인데 생략되어있는거다.

public interface UserDao {

	int deleteUser(String id);

	User selectUser(String id) throws Exception;


	int insertUser(User user);

	int updateUser(User user);

	void deleteAll() throws Exception;

}