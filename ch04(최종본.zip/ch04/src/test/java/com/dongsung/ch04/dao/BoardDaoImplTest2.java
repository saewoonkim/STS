package com.dongsung.ch04.dao;

import static org.junit.Assert.assertTrue;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.dongsung.ch04.domain.BoardDto;
import com.dongsung.ch04.domain.SearchCondition;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"file:src/main/webapp/WEB-INF/spring/**/root-context.xml"})
public class BoardDaoImplTest2 {
	
	@Autowired
	private BoardDao boardDao;
	
	
	
	
	@Test
	public void searchResultCntTest() throws Exception{
		boardDao.deleteAll();
		for (int i=1; i<=20; i++) {
			BoardDto boardDto = new BoardDto("title"+1, "asdfasdf", "asdf");
			boardDao.insert(boardDto);
		}
		
		SearchCondition sc = new SearchCondition(1, 10, "title2", "T");
		int cnt = boardDao.searchResultCnt(sc);
		System.out.println("cnt" + cnt);
		assertTrue(cnt==0);// 1~20, title
	}
	
	
	
	@Test
	public void searchSelectPageTest() throws Exception{
		boardDao.deleteAll();
		for (int i=1; i<=20; i++) {
			BoardDto boardDto = new BoardDto("title"+i, "asdfasdfasdf", "asdf"); //title/ content/ writer
			boardDao.insert(boardDto);
		}
		
		SearchCondition sc = new SearchCondition(1, 10, "title2", "T"); //������/������������/Ű����/�ɼ�
		List<BoardDto> list = boardDao.searchSelectPage(sc);
		System.out.println("list = " + list);
		assertTrue(list.size()==2); //1~20, title1, title20
	}
	

	@Test
	public void countTest() throws Exception {
		boardDao.deleteAll();
		assertTrue(boardDao.count()==0);
		
		BoardDto boardDto = new BoardDto("no title", "no content", "asdf");
		assertTrue(boardDao.insert(boardDto)==1);
		assertTrue(boardDao.count()==1);
		
		assertTrue(boardDao.insert(boardDto)==1);
		assertTrue(boardDao.count()==2);
	}
	
	@Test
	public void deleteAllTest() throws Exception{
		boardDao.deleteAll();
		assertTrue(boardDao.count()==0);
		
		BoardDto boardDto = new BoardDto("no title", "no content", "asdf");
		assertTrue(boardDao.insert(boardDto)==1);
		assertTrue(boardDao.deleteAll()==1);
		assertTrue(boardDao.count()==0);
		
		boardDto = new BoardDto("no title", "no content", "asdf");
		assertTrue(boardDao.insert(boardDto)==1);
		assertTrue(boardDao.insert(boardDto)==1);
		assertTrue(boardDao.deleteAll()==2);
		assertTrue(boardDao.count()==0);
				
		
	}
	
	@Test
	public void updateTest() throws Exception{
		boardDao.deleteAll();
		BoardDto boardDto = new BoardDto("no title", "no content", "asdf");
		assertTrue(boardDao.insert(boardDto)==1);
		
		Integer bno=boardDao.selectAll().get(0).getBno();
		System.out.println("bno=" + bno);
		boardDto.setBno(bno);
		boardDto.setTitle("yes title");
		assertTrue(boardDao.update(boardDto)==1);
		
		BoardDto boardDto2 = boardDao.select(bno);
		System.out.println("boardDao =" + boardDto);
		System.out.println("boardDao2 =" + boardDto2);
		assertTrue(boardDto.equals(boardDto2));
		
	}
	
	
	@Test
	public void insertTestDate() throws Exception{
		boardDao.deleteAll();
		for(int i = 1;i<= 220; i++) {
			BoardDto boardDto = new BoardDto("title"+1,"no content", "asdf");
			boardDao.insert(boardDto);
			
		}
	}

}
