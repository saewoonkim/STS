package com.dongsung.ch04;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import javax.sql.DataSource;

//주석 가나다 설명 다 하고 UserDao를 인터페이스로 만듬.
//UserDao 오른쪽 클릭 Refactor-> Extract Interface
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


@Repository
//가 1. 이 UserDao는 지난번에 만든 메서드 다 모아놓은거다.
public class UserDaoImpl implements UserDao  {
	//가 2. 데이터 소스 주입받아서.
    @Autowired
    DataSource ds; //데이터베이스 연결을 위한 DataSource 객체를 선언
    final int FAIL = 0;
    //가 4.  메서드 보면 예외선언했던거 다 지우고 아래 try Catch문으로 감싸줬다.
    //가 5.  테스트 할때는 예외 선언해서 예외 발생해도 상관없지만.
    //가 6.  우리가 실무에서는 무조건 예외를 선언하지 말고 어디선가 반드시 예외를 처리해주게 만들어줘야 된다.
    //가 7.  만약 여기서 바로 예외를 선언해주게 되면. 데이터베이스하고 관련된 배부분의 작업은 컨트롤러와 같은 다른 계층에서 그 예외를 적절히 처리할 수가 없다.
    //가 8.  그래서 메서드에 예외를 선언해서 예외를 전달하는거 보다는 다오에 있는 메서드들이 예외를 처리하도록 헀다.
    //가 9.  대신에 deleteUser 같은 메서드가 삭제를 실패하면.
    //가 10. executeUpdate 반환값이 0이 된다.
    //가 11. 딜리트에 실패하면 데이터베이스가 영향받은 행이 0이니까.
    //가 12. 그래스 그것만으로도 딜리트 유저를 호출한 쪽에서 알 수가 있다. 작업에 성공했는지 실패했는지.
    //가 11. 이 deleteUser메서드는 데이터베이스에 연결해서 작업을 하는거기 때문에
    //가 12. 작업중에 문제가 생겨서 발생한 예외를 deleteUser를 호출한 쪽에서 받아서 처리할게 없다
    //가 13. 그렇기 때문에 delteUser에서 예외가 발생하면
    //가 14. 맨위에 final int FAIL=0;이라는 상수를 정의해서
    //가 15. return FAIL에 쓴거다.
    //가 16. 그래서 예외가 발생하면 그냥 예외를 출력하고 0을 반환하도록 작성을 했다
    //가 17. 그리고 이 메서드가 사용한 Connection conn = null 커넥션하고
    //가 18.  PreparedStatement pstmt = null; 프리페어드스테이트먼트 객체는 아래처럼 close(pstmt,conn) 해줘야 된다.
    //가 19. 저번 강의에서는 생략을 한건데. 사실을 close 해줘야 된다. 안그러면 메모리가 제대로 반환되지 않아서
    //가 20. 점점 메모리가 부족해지기 때문에 메모리가 발생할 수 있다.
    
    @Override
	public int deleteUser(String id) {
        int rowCnt = FAIL; //  insert, delete, update
        
        Connection conn = null; //명확성, 자원 관리 및 예외 처리를 위한 관습적인 방법
        
        PreparedStatement pstmt = null;

        String sql = "delete from user_info where id= ? ";

        try {

            conn = ds.getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, id);
//        int rowCnt = pstmt.executeUpdate(); //  insert, delete, update
//        return rowCnt;
            
            return pstmt.executeUpdate(); // 삭제에 실패하면 executeUpdate()의 반환값이 0 
        } catch (SQLException e) {
            e.printStackTrace(); 
            return FAIL;
        } finally {

//            try { if(pstmt!=null) pstmt.close(); } catch (SQLException e) { e.printStackTrace();}
//            try { if(conn!=null)  conn.close();  } catch (SQLException e) { e.printStackTrace();}
           
//        	close라는 메서드를 이용해서 간단히 처리를 한거다.
        	close(pstmt, conn); //     private void close(AutoCloseable... acs) {
        }
    }

    @Override
	public User selectUser(String id) throws Exception {
        User user = null;

        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        String sql = "select * from user_info where id= ? ";

        try {
        	//클로즈할때는 순서가 있는데, 일단 생성할때는 커넥션 먼저 만들고
            conn = ds.getConnection();
            //그 다음에 프리페어드스테이트먼트 만들어지고
            pstmt = conn.prepareStatement(sql); // SQL Injection공격, 성능향상

            pstmt.setString(1, id);
            
            
            //그 다음에 리절트셋 만들어진다.
            //근데 해제할때는 반대로 리절트셋부터 하고
            //그 다음 프리페어드스테이트먼트 하고, 커넥션 이런 순서로 해제를 해야된다.
            rs = pstmt.executeQuery(); //  select

            if (rs.next()) {
                user = new User();
                user.setId(rs.getString(1));
                user.setPwd(rs.getString(2));
                user.setName(rs.getString(3));
                user.setEmail(rs.getString(4));
                user.setBirth(new Date(rs.getDate(5).getTime()));
                user.setSns(rs.getString(6));
                user.setReg_date(new Date(rs.getTimestamp(7).getTime()));
            }
        } catch (SQLException e) {
            return null;
        } finally {
            // close()를 호출하다가 예외가 발생할 수 있으므로, try-catch로 감싸야함.
            // close()의 호출순서는 생성된 순서의 역순
        	
 
//            try { if(rs!=null)    rs.close();    } catch (SQLException e) { e.printStackTrace();}
//            try { if(pstmt!=null) pstmt.close(); } catch (SQLException e) { e.printStackTrace();}
//            try { if(conn!=null)  conn.close();  } catch (SQLException e) { e.printStackTrace();}
            
        	//그래서 순서대로 호출 한거다.
        	//매개변수가 가변인지라 여러개 넣어도 된다.
        	//지금까지는 근데 close라는 메서드를 사용해서 호출을 했는데. 사실 이렇게 할 필요가 없다
        	close(rs, pstmt, conn);  //     private void close(AutoCloseable... acs) {
        }

        return user;
    }

    // 사용자 정보를 user_info테이블에 저장하는 메서드
    @Override
	public int insertUser(User user) {
        int rowCnt = FAIL;

        Connection conn = null;
        PreparedStatement pstmt = null;

//        insert into user_info (id, pwd, name, email, birth, sns, reg_date)
//        values ('asdf22', '1234', 'smith', 'aaa@aaa.com', '2022-01-01', 'facebook', now());
        String sql = "insert into user_info values (?, ?, ?, ?,?,?, now()) ";
        
        
        
        try {
        	
            conn = ds.getConnection();
            
            pstmt = conn.prepareStatement(sql); // SQL Injection공격, 성능향상
        
            pstmt.setString(1, user.getId());
            pstmt.setString(2, user.getPwd());
            pstmt.setString(3, user.getName());
            pstmt.setString(4, user.getEmail());
            pstmt.setDate(5, new java.sql.Date(user.getBirth().getTime()));
            pstmt.setString(6, user.getSns());

            return pstmt.executeUpdate(); //  insert, delete, update;
        } catch (SQLException e) {
            e.printStackTrace();
            return FAIL;
        } finally {
            close(pstmt, conn);  //     private void close(AutoCloseable... acs) {
        }
    }

    // 매개변수로 받은 사용자 정보로 user_info테이블을 update하는 메서드
    
    //다 0.저번 시간에 updateUser 작성해보라고 했다.
    //다 1.이렇게 작성하면 된다.
    @Override
	public int updateUser(User user) {
        int rowCnt = FAIL; //  insert, delete, update

//        Connection conn = null;
//        PreparedStatement pstmt = null;

        String sql = "update user_info " +
                     "set pwd = ?, name=?, email=?, birth =?, sns=?, reg_date=? " +
                     "where id = ? ";

        // try-with-resources - since jdk7
        
        //나 0.위에서는 close 메서드를 사용했는데 사실 저렇게 해줄 필요가 없다.
        //나 1.jdk7부터 try-with-resources라는 구문이 나왔기 때문이다.
        //나 2.이 close를 하나 해주려고 일일이 자원을 반환할 필요가 없다
        //나 3.그래서 나온게 try-with-resources라는 구문이다.
        //나 4.try-with-resources구문은 finally가 없다.
        //나 5.위에처럼 close구문 쓰면 메서드 만들어 줘야 하니까 귀찮고
        //나 6.메서드를 안만들고 try catch문으로 쓰면 더 귀찮기 때문이다.
        try (
        		
        //나 7.트라이문 실행하기 전에 괄호 안에다가
        //나 8.트라이캐치문에서 사용 할 객체들을 먼저 만든다
        //나 9.그리고 괄호안에 선언된 커넥션이랑 프리메어드스테이트먼트는
            Connection conn = ds.getConnection();
            PreparedStatement pstmt = conn.prepareStatement(sql); // SQL Injection공격, 성능향상
        ){
       	//나 10.	 이 트라이캐치 블럭에서 작업을 하다가
        //나 11. 예외가 발생하건 안하건 자동으로 close가 되게 되어있다.
        //나 12. 이게 더 깔끔하기 때문에 이렇게 하면 된다.
        //나 13. 근데 모든 객체를 다 try-with-resources에 쓸 수 있는게 아니라
        //나 14. AutoCloseable. 자동으로 close 할 수 있는 객체들만 여기 들어올 수 있다.
        //나 15. 이 커넥션과 프리메어드스테이트먼트는 다 인터페이스고
        //나 16. AutoCloseable를 구현하고 있다.
            pstmt.setString(1, user.getPwd());
            pstmt.setString(2, user.getName());
            pstmt.setString(3, user.getEmail());
            pstmt.setDate(4, new java.sql.Date(user.getBirth().getTime()));// 위에 보면 Date는 util.Date이다 근데 sql에 넣을때는 sql.Date로 넣어줘야 돼서 변환해준거다.
            pstmt.setString(5, user.getSns());
            pstmt.setTimestamp(6, new java.sql.Timestamp(user.getReg_date().getTime()));//날짜 시간 다 들어가려면 타임스탬프로 변환해줘야 된다.
            pstmt.setString(7, user.getId());

            rowCnt = pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            return FAIL;
        }

        return rowCnt;
    }

    @Override
	public void deleteAll() throws Exception {
        Connection conn = ds.getConnection();

        String sql = "delete from user_info ";

        PreparedStatement pstmt = conn.prepareStatement(sql); // SQL Injection공격, 성능향상
        pstmt.executeUpdate(); //  insert, delete, update
    }
    
    //매개변수로 가변인자를 선언했기 때문에. close의 매개변수로 여러개를 쓸 수 있다.
    //아무튼 그게 배열로 바껴서 들어가서 for문 돌면서 두번 처리하게 된다.
    //pstmt와 conn은 둘다 AutoClosebale이라는 인터페이스를 구현했기 때문에 가능한거고
    private void close(AutoCloseable... acs) {
        for(AutoCloseable ac :acs)
            try { if(ac!=null) ac.close(); } catch(Exception e) { e.printStackTrace(); }
    }
}