package com.dongsung.SpringExam2;


public interface UserDao {

	int deleteUser(String id);

	User selectUser(String id) throws Exception;


	int insertUser(User user);

	int updateUser(User user);

	void deleteAll() throws Exception;

}