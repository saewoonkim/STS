package com.dongsung.ch04.dao;

import java.util.List;
import java.util.Map;

import com.dongsung.ch04.domain.BoardDto;

public interface BoardDao {

	int count() throws Exception;

	List<BoardDto> selectAll() throws Exception;

	BoardDto select(Integer bno) throws Exception;

	int deleteAll() throws Exception;

	int delete(Integer bno, String writer) throws Exception;

	int insert(BoardDto dto) throws Exception;

	int update(BoardDto dto) throws Exception;

	int increaseViewCnt(Integer bno) throws Exception;

	List<BoardDto> selectPage(Map map) throws Exception;

}